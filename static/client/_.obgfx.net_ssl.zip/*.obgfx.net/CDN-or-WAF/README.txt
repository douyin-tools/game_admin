Certificate: try `fullchain.crt`
Private Key: Try upload or paste `private-a.key` first, if malformed please try `private-b.key`